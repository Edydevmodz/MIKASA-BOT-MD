# ⚔️ Mikasa BOT V1.0

WhatsApp Multi-Device bot (Baileys `@systemzero/baileys`) — estilo **Mikasa**.

## Instalação (Termux / Linux)

```bash
cd /storage/emulated/0/Download/MIKASAV1
# ou: cd ~/MIKASAV1

pkg install nodejs ffmpeg -y   # Termux
npm install --no-bin-links     # se EACCES no storage, use pasta home

node index.js
```

## Config

Edite `settings/settings.js`:
- `donoPrincipal` / `subDonos`
- `geminiApiKey`
- `prefix`, `chanell`, `chavePix`, etc.

## Identidade

| Item | Valor |
|------|--------|
| Nome | ⚔️ Mikasa BOT |
| Pack figurinha | ⟡⚔️ MIKASA⚔️⟡ |
| Key permanente | EDY-KEYPERM-MIKASA |
| AI | `/mikasaai` `/ia` `/gpt` |

## Comandos principais

- `/menu` — menus
- `/protocolonamoro` — proteção de casal
- `/bypass` — bypass de links
- `/ping` — status
- `/denunciar` — B.O.
- `/registrarcpf` — CPF interno do bot

Mesma base de comandos do Astolfo V3, rebranded para Mikasa.
