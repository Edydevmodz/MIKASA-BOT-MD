const { enviarAcaoGif } = require("../lib/gifAction")
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: "abraco_lado",
        emoji: "🤗",
        frase: "abraçou de lado {alvo}",
        gifQuery: "anime side hug",
        precisaAlvo: true,
        args
    })
}
