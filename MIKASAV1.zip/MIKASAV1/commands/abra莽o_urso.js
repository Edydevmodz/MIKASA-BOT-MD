const { enviarAcaoGif } = require("../lib/gifAction")
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: "abraço_urso",
        emoji: "🐻",
        frase: "deu abraço de urso em {alvo}",
        gifQuery: "anime bear hug",
        precisaAlvo: true,
        args
    })
}
