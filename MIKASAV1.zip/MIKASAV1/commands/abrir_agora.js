module.exports = async (client, info, args, ctx) => {
  if (!ctx.from.endsWith('@g.us')) return ctx.escrever('❌ Só grupos')
  if (!ctx.isAdmin && !ctx.isDono) return ctx.escrever('❌ Só admin')
  if (!ctx.isBotAdmin) return ctx.escrever('❌ Bot precisa ser admin')
  await client.groupSettingUpdate(ctx.from, 'not_announcement')
  await ctx.escrever('🔓 Grupo aberto')
}
