module.exports = require('./abrir_frchar_grupo_automatico.js')
