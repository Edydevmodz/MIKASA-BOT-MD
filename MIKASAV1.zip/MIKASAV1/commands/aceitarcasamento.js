case 'aceitarcasamento': {
const path = './database/familia.json';

if (!fs.existsSync('./database')) fs.mkdirSync('./database', { recursive: true });
if (!fs.existsSync(path)) fs.writeFileSync(path, '{}');

const familia = JSON.parse(fs.readFileSync(path));

const userId = jidNormalizedUser(sender);

let chavePedido = null;

if (familia[userId]?.pedidoCasamento) {
chavePedido = userId;
} else {
const numero = userId.split('@')[0];

const achou = Object.keys(familia).find(k =>
k.split('@')[0] === numero &&
familia[k]?.pedidoCasamento
);

if (achou) chavePedido = achou;
}

if (!chavePedido) {
return reply(`❌ Você não possui pedidos de casamento.

ID: ${userId}`);
}

const parceiro = familia[chavePedido].pedidoCasamento.de;

familia[chavePedido] = {
...(familia[chavePedido] || {}),
casadoCom: parceiro,
casadoDesde: Date.now(),
filhos: familia[chavePedido]?.filhos || []
};

familia[parceiro] = {
...(familia[parceiro] || {}),
casadoCom: chavePedido,
casadoDesde: Date.now(),
filhos: familia[parceiro]?.filhos || []
};

delete familia[chavePedido].pedidoCasamento;

fs.writeFileSync(path, JSON.stringify(familia, null, 2));

return conn.sendMessage(from, {
text: `╭━━〔 💍 CASAMENTO ACEITO 〕━━⬣
┃ ❤️ @${chavePedido.split('@')[0]}
┃ ❤️ @${parceiro.split('@')[0]}
┃
┃ Agora vocês estão casados!
╰━━━━━━━━━━━━━━⬣`,
mentions: [chavePedido, parceiro]
}, { quoted: selo });
}
break;