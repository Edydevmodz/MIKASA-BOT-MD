module.exports=async(client,info,args,ctx)=>{
if(!ctx.from.endsWith('@g.us'))return ctx.escrever('❌ Só grupos');
if(!ctx.isAdmin&&!ctx.isDono)return ctx.escrever('❌ Só admin');
if(!ctx.isBotAdmin)return ctx.escrever('❌ Bot admin');
const n=(args[0]||'').replace(/\D/g,'');
if(!n)return ctx.escrever('❌ Número');
try{await client.groupParticipantsUpdate(ctx.from,[n+'@s.whatsapp.net'],'add');await ctx.escrever('✅ Tentativa de add')}catch(e){await ctx.escrever('❌ '+e.message)}
};