module.exports = async (client, info, args, ctx) => {
  if (!ctx.from.endsWith('@g.us')) return ctx.escrever('❌ Só grupos')
  if (!ctx.isAdmin && !ctx.isDono) return ctx.escrever('❌ Só admin')
  try {
    const m = await client.groupMetadata(ctx.from)
    await ctx.escrever('🛡️ *addmembro*\nGrupo: ' + m.subject + '\nMembros: ' + (m.participants||[]).length)
  } catch (e) { await ctx.escrever('❌ ' + e.message) }
}
