/**
 * /adverter @usuario — +1 advertência (persistente)
 * 3/3 → mute
 */
const grupos = require('../lib/grupos')
const adv = require('../lib/advertencias')
const config = require('../lib/config')

function pegarAlvo(info, args) {
    const ctx = info?.message?.extendedTextMessage?.contextInfo || {}
    if (ctx.mentionedJid?.[0]) return ctx.mentionedJid[0]
    if (args[0]) {
        const n = args[0].replace(/\D/g, '')
        if (n) return n + '@s.whatsapp.net'
    }
    return null
}

module.exports = async (client, info, args, contexto) => {
    const { from, isAdmin, isBotAdmin, isDono, escrever, reagir } = contexto
    const prefix = (config.prefix && config.prefix()) || '/'
    const foot = (config.footer && config.footer()) || '⚔️ Mikasa BOT'

    if (!from.endsWith('@g.us')) return await escrever('❌ Só funciona em grupos.')
    if (!isAdmin && !isDono) return await escrever('❌ Apenas administradores.')
    if (!isBotAdmin) return await escrever('❌ Preciso ser admin do grupo.')

    const alvo = pegarAlvo(info, args)
    if (!alvo) return await escrever(`❌ Marque alguém.\nEx: *${prefix}adverter @usuario*`)

    try { await reagir(from, '⚠️') } catch {}

    const quem = info.key?.participant || info.key?.remoteJid
    const total = adv.add(from, alvo, quem, 'adverter')
    // mantém grupos em sincronia
    try { grupos.addAdvertencia(from, alvo) } catch {}

    const num = alvo.split('@')[0]
    let extra = ''
    if (total >= 3) {
        try {
            grupos.mutar(from, alvo, null)
            grupos.resetAdvertencias(from, alvo)
            adv.reset(from, alvo, quem)
        } catch {}
        extra = `\n\n🔇 *Limite atingido (3/3)*\n@${num} foi *MUTADO* automaticamente.`
    }

    await client.sendMessage(from, {
        text: `⚠️ *ADVERTÊNCIA ${Math.min(total, 3)}/3*\n👤 @${num}${extra}\n\n💾 Registro salvo (persiste se cair a conexão).\n\n${foot}`,
        mentions: [alvo]
    }, { quoted: info })
}
