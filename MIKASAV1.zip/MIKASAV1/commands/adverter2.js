/**
 * /adverter2 @user — 3 advertências = BAN
 */
const grupos = require('../lib/grupos')
const config = require('../lib/config')

function pegarAlvo(info, args) {
    const ctx = info?.message?.extendedTextMessage?.contextInfo || {}
    if (ctx.mentionedJid?.[0]) return ctx.mentionedJid[0]
    if (ctx.participant && ctx.quotedMessage) return ctx.participant
    if (args[0]) {
        const n = String(args[0]).replace(/\D/g, '')
        if (n) return n + '@s.whatsapp.net'
    }
    return null
}

module.exports = async (client, info, args, ctx) => {
    const { from, isAdmin, isBotAdmin, isDono, escrever, reagir } = ctx
    const foot = config.footer()
    const prefix = config.prefix()

    if (!from.endsWith('@g.us')) return escrever('❌ Só em grupos.')
    if (!isAdmin && !isDono) return escrever('❌ Só admin/dono.')
    if (!isBotAdmin) return escrever('❌ Preciso ser admin.')

    const alvo = pegarAlvo(info, args)
    if (!alvo) return escrever(`❌ Marque alguém.\nEx: *${prefix}adverter2 @usuario*`)

    try { await reagir(from, '⚠️') } catch {}

    const total = grupos.addAdvertencia2(from, alvo)
    const num = alvo.split('@')[0]

    if (total >= 3) {
        grupos.clearAdvertencias2(from, alvo)
        try {
            await client.groupParticipantsUpdate(from, [alvo], 'remove')
        } catch (e) {
            return escrever(`⚠️ 3/3 atingido, mas não consegui banir: ${e.message}`)
        }
        return client.sendMessage(from, {
            text: `🚫 *ADVERTÊNCIA 2 — 3/3*\n👤 @${num}\n\n*BANIDO* automaticamente.\n\n${foot}`,
            mentions: [alvo]
        }, { quoted: info })
    }

    await client.sendMessage(from, {
        text: `⚠️ *ADVERTÊNCIA 2 — ${total}/3*\n👤 @${num}\n\nAo atingir *3*, o membro será *BANIDO*.\n\n${foot}`,
        mentions: [alvo]
    }, { quoted: info })
}
