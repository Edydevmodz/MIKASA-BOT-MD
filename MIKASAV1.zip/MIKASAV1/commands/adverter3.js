/**
 * /adverter3 1|0 — auto: porno + links de terceiro → adverter2 (3=ban)
 */
const grupos = require('../lib/grupos')
const config = require('../lib/config')

function ativarAdverter3(gid, v) {
    if (typeof grupos.setAdverter3 === 'function') {
        return grupos.setAdverter3(gid, v)
    }
    // fallback se grupos.js antigo no celular
    if (typeof grupos.setGrupo === 'function') {
        return grupos.setGrupo(gid, { adverter3: !!v, antiporno: !!v })
    }
    throw new Error('grupos.setAdverter3/setGrupo indisponível — atualize lib/grupos.js')
}

module.exports = async (client, info, args, ctx) => {
    const { from, isAdmin, isDono, escrever, reagir, texto, prefix } = ctx || {}
    if (!from.endsWith('@g.us')) return escrever('❌ Só em grupos.')
    if (!isAdmin && !isDono) return escrever('❌ Só admin/dono.')

    try { await reagir(from, '🤖') } catch {}
    const arg = (texto || (args || []).join(' ') || '').trim().toLowerCase()
    const p = prefix || (config.prefix && config.prefix()) || '/'

    try {
        if (['1', 'on', 'ativar'].includes(arg)) {
            ativarAdverter3(from, true)
            if (typeof grupos.setAntiporno === 'function') grupos.setAntiporno(from, true)
            return escrever(
                `✔️ *Adverter3 ATIVADO*\n` +
                `Detecta automaticamente:\n` +
                `• conteúdo adulto (texto/link/mídia)\n` +
                `• links de terceiro\n` +
                `• evasão com caracteres\n\n` +
                `Cada detecção = *+1 adverter2* (3 = ban).\n` +
                `${p}adverter3 0 — desativar`
            )
        }
        if (['0', 'off', 'desativar'].includes(arg)) {
            ativarAdverter3(from, false)
            return escrever(`❌ *Adverter3 DESATIVADO*`)
        }

        const { g } = grupos.getGrupo(from)
        const st = g.adverter3 ? '🟢 ATIVO' : '🔴 DESATIVADO'
        await escrever(
            `┌─「🤖 𝐀𝐃𝐕𝐄𝐑𝐓𝐄𝐑𝟑 」\n│ Status: *${st}*\n└────────────\n\n` +
            `Auto-moderação: porno, links de terceiro, evasão…\n` +
            `Usa *adverter2* (3 = ban).\n\n` +
            `✧ ${p}adverter3 1 — ativar\n✧ ${p}adverter3 0 — desativar`
        )
    } catch (e) {
        console.error('[adverter3]', e)
        await escrever('❌ Erro: ' + (e.message || e) + '\n\nAtualize o arquivo *lib/grupos.js* do bot.')
    }
}
