const axios = require('axios')
module.exports = async (client, info, args, ctx) => {
  const { data } = await axios.get('https://api.adviceslip.com/advice', { timeout: 12000 })
  await ctx.escrever('💡 ' + data.slip.advice)
}
