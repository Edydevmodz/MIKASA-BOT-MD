const afk = require('../lib/afk')

module.exports = async (client, info, args, ctx) => {
    const { from, escrever, reagir, texto, remetenteJid, pushName, prefix } = ctx || {}
    try { await reagir(from, '💤') } catch {}

    const motivo = (texto || (args || []).join(' ') || '').trim() || 'Sem motivo'
    afk.setAfk(remetenteJid, motivo, pushName)

    await escrever(
        `💤 *AFK ativado*\n` +
        `👤 ${pushName || 'Você'}\n` +
        `📝 Motivo: *${motivo}*\n\n` +
        `_Quando você mandar outra mensagem, o bot avisa que voltou e o tempo AFK._`
    )
}
