module.exports=async(client,info,args,ctx)=>{
if(!ctx.isDono)return ctx.escrever('❌ Só dono');
await ctx.escrever('👑 *agendar msg*\nFerramenta do dono.')}
