const grupos = require('../lib/grupos')
const config = require('../lib/config')

module.exports = async (client, info, args, ctx) => {
    const { from, isAdmin, isDono, escrever, reagir, texto, prefix } = ctx || {}
    if (!from.endsWith('@g.us')) return escrever('❌ Só em grupos.')
    if (!isAdmin && !isDono) return escrever('❌ Só admin/dono.')

    try { await reagir(from, '🔕') } catch {}
    const arg = (texto || (args || []).join(' ') || '').trim().toLowerCase()
    const p = prefix || '/'

    if (['1', 'on', 'ativar'].includes(arg)) {
        grupos.setAllblock(from, true)
        return escrever(
            `✔️ *AllBlock ATIVADO*\n` +
            `Menções em massa (@todos / @all / marcar quase todos) serão *apagadas*.\n` +
            `O bot só reclama — *sem citar* a mensagem.\n\n` +
            `${p}allblock 0 — desativar`
        )
    }
    if (['0', 'off', 'desativar'].includes(arg)) {
        grupos.setAllblock(from, false)
        return escrever(`❌ *AllBlock DESATIVADO*`)
    }

    const { g } = grupos.getGrupo(from)
    const st = g.allblock ? '🟢 ATIVO' : '🔴 DESATIVADO'
    await escrever(
        `┌─「🔕 𝐀𝐋𝐋𝐁𝐋𝐎𝐂𝐊 」\n│ Status: *${st}*\n└────────────\n\n` +
        `Anti menção a todos.\n\n` +
        `✧ ${p}allblock 1 — ativar\n✧ ${p}allblock 0 — desativar`
    )
}
