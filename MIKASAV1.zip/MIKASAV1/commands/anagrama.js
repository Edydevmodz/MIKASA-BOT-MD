module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto } = ctx || {}
  try { await reagir(from, '✨') } catch {}
  try {
    const q = (texto || '').replace(/\s/g, '')
    if (!q) return escrever('❌ /anagrama palavra')
    const a = q.split('')
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]] }
    await escrever('🔤 *' + a.join('') + '*')
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
