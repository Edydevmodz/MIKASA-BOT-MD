const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *anagrama jogo*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'anagrama_jogo*')+'\n\n'+config.footer())}
