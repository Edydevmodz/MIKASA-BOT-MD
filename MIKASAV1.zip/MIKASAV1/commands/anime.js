const axios = require('axios')
const config = require('../lib/config')
module.exports = async (client, info, args, ctx) => {
  const q = (ctx.texto || args.join(' ') || '').trim()
  if (!q) return ctx.escrever('❌ *' + config.prefix() + 'anime nome*')
  try {
    const { data } = await axios.get('https://api.jikan.moe/v4/anime?q=' + encodeURIComponent(q) + '&limit=1', { timeout: 20000 })
    const a = data.data?.[0]
    if (!a) return ctx.escrever('❌ Não achei')
    const cap = '🎌 *' + a.title + '*\n⭐ ' + (a.score || '—') + ' | Ep: ' + (a.episodes || '?') + '\n' + String(a.synopsis || '').slice(0, 400)
    if (a.images?.jpg?.image_url) await client.sendMessage(ctx.from, { image: { url: a.images.jpg.image_url }, caption: cap + '\n' + config.footer() }, { quoted: info })
    else await ctx.escrever(cap)
  } catch (e) { await ctx.escrever('❌ ' + e.message) }
}
