const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *anime nome*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'anime_nome*')+'\n\n'+config.footer())}
