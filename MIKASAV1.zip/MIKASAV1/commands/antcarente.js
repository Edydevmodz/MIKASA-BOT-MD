module.exports = require('./ant_carente.js')
