module.exports = require('./antibullying')
