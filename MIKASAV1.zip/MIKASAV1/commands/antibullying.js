const grupos = require('../lib/grupos')
const config = require('../lib/config')

module.exports = async (client, info, args, ctx) => {
    const { from, isAdmin, isDono, escrever, reagir, texto, prefix } = ctx || {}
    if (!from.endsWith('@g.us')) return escrever('❌ Só em grupos.')
    if (!isAdmin && !isDono) return escrever('❌ Só admin/dono.')

    try { await reagir(from, '🛡️') } catch {}
    const arg = (texto || (args || []).join(' ') || '').trim().toLowerCase()
    const p = prefix || config.prefix()

    if (['1', 'on', 'ativar'].includes(arg)) {
        grupos.setAntibully(from, true)
        return escrever(`✔️ *Anti-Bullying ATIVADO*\nOfensas graves serão detectadas e o autor advertido.\n\n${p}antibullying 0 — desativar`)
    }
    if (['0', 'off', 'desativar'].includes(arg)) {
        grupos.setAntibully(from, false)
        return escrever(`❌ *Anti-Bullying DESATIVADO*`)
    }

    const { g } = grupos.getGrupo(from)
    const st = g.antibully ? '🟢 ATIVO' : '🔴 DESATIVADO'
    await escrever(
        `┌─「🛡️ 𝐀𝐍𝐓𝐈-𝐁𝐔𝐋𝐋𝐘𝐈𝐍𝐆 」\n│ Status: *${st}*\n└────────────\n\n` +
        `Detecta ofensas/bullying e aplica *adverter2* (3 = ban).\n\n` +
        `✧ ${p}antibullying 1 — ativar\n✧ ${p}antibullying 0 — desativar`
    )
}
