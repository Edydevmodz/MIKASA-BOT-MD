const grupos = require('../lib/grupos')
const config = require('../lib/config')

module.exports = async (client, info, args, contexto) => {
    const { from, isAdmin, isDono, escrever, reagir, texto } = contexto
    const prefix = config.prefix()
    const foot = config.footer()

    if (!from.endsWith('@g.us')) return await escrever('❌ Só em grupos.')
    if (!isAdmin && !isDono) return await escrever('❌ Só administradores.')

    const arg = (texto || args?.[0] || '').trim().toLowerCase()

    if (arg === '1' || arg === 'on' || arg === 'ativar') {
        grupos.setAnticode(from, true)
        return await escrever(
            `✔️ *Anticode ATIVADO*\n` +
            `Cada membro: no máx. *10 comandos a cada 20 minutos*.\n` +
            `Admins e dono não são limitados.\n\n${foot}`
        )
    }
    if (arg === '0' || arg === 'off' || arg === 'desativar') {
        grupos.setAnticode(from, false)
        return await escrever(`❌ *Anticode DESATIVADO*\n\n${foot}`)
    }

    const { g } = grupos.getGrupo(from)
    const status = g.anticode ? '🟢 ATIVO' : '🔴 DESATIVADO'
    try { await reagir(from, '⏱️') } catch {}

    await escrever(
`┌─「⚔️𝐀𝐍𝐓𝐈𝐂𝐎𝐃𝐄⚔️ 」
│ Status: *${status}*
│ Limite: *10 comandos / 20 min*
└────────────

${prefix}anticode 1 — ativar
${prefix}anticode 0 — desativar

${foot}`
    )
}
