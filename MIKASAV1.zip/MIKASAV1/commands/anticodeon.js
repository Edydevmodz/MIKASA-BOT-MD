const grupos = require('../lib/grupos')
module.exports = async (client, info, args, ctx) => {
  if (!ctx.from.endsWith('@g.us')) return ctx.escrever('❌ Só grupos')
  if (!ctx.isAdmin && !ctx.isDono) return ctx.escrever('❌ Só admin')
  try {
    if (typeof grupos.set === 'function') grupos.set(ctx.from, 'anticode', true)
    else if (typeof grupos.salvar === 'function') {}
    await ctx.escrever('✅ *anticodeon* aplicado')
  } catch (e) { await ctx.escrever('⚙️ Use o comando principal correspondente (ex: antilink 1/0)') }
}
