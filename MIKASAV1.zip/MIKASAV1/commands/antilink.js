const grupos = require('../lib/grupos')
const config = require('../lib/config')

module.exports = async (client, info, args, contexto) => {
    const { from, isAdmin, isDono, isBotAdmin, escrever, reagir, texto } = contexto
    const prefix = config.prefix()
    const foot = config.footer()

    if (!from.endsWith('@g.us')) return await escrever('❌ Só em grupos.')
    if (!isAdmin && !isDono) return await escrever('❌ Só admins.')

    const arg = (texto || args?.[0] || '').trim().toLowerCase()
    if (arg === '1' || arg === 'on' || arg === 'ativar') {
        grupos.setAntilink(from, true)
        return await escrever(`✔️ *Antilink ATIVADO*\nLinks de membros comuns serão apagados.\n\n${foot}`)
    }
    if (arg === '0' || arg === 'off' || arg === 'desativar') {
        grupos.setAntilink(from, false)
        return await escrever(`❌ *Antilink DESATIVADO*\n\n${foot}`)
    }

    const { g } = grupos.getGrupo(from)
    const status = g.antilink ? '🟢 ATIVO' : '🔴 DESATIVADO'
    try { await reagir(from, '🔗') } catch {}

    const caption = `┌─「⚔️𝐀𝐍𝐓𝐈𝐋𝐈𝐍𝐊⚔️ 」
│ Status: *${status}*
└────────────

Apaga mensagens com links de membros comuns.
Escolha abaixo:
${foot}`

    try {
        await client.sendMessage(from, {
            text: caption,
            footer: config.nomebot(),
            nativeFlow: [
                {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: '✔️ ATV Ativar',
                        id: `${prefix}antilink 1`
                    })
                },
                {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: '❌ DST Desativar',
                        id: `${prefix}antilink 0`
                    })
                }
            ]
        }, { quoted: info })
    } catch {
        await escrever(caption + `\n\n${prefix}antilink 1 — ativar\n${prefix}antilink 0 — desativar`)
    }
}
