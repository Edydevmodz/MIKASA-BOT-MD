/**
 * /antiporno 1|0 — só detecção de conteúdo adulto (sem forçar links genéricos)
 */
const grupos = require('../lib/grupos')
const config = require('../lib/config')

function setAP(gid, v) {
    if (typeof grupos.setAntiporno === 'function') return grupos.setAntiporno(gid, v)
    if (typeof grupos.setGrupo === 'function') return grupos.setGrupo(gid, { antiporno: !!v })
    throw new Error('Atualize lib/grupos.js')
}

module.exports = async (client, info, args, ctx) => {
    const { from, isAdmin, isDono, escrever, reagir, texto, prefix } = ctx || {}
    if (!from.endsWith('@g.us')) return escrever('❌ Só em grupos.')
    if (!isAdmin && !isDono) return escrever('❌ Só admin/dono.')

    try { await reagir(from, '🔞') } catch {}
    const arg = (texto || (args || []).join(' ') || '').trim().toLowerCase()
    const p = prefix || '/'

    try {
        if (['1', 'on', 'ativar'].includes(arg)) {
            setAP(from, true)
            return escrever(
                `✔️ *Anti-Porno ATIVADO*\n` +
                `Detecta texto/link/legenda adultos e aplica adverter2.\n\n` +
                `${p}antiporno 0 — desativar\n` +
                `(Completo com links: ${p}adverter3 1)`
            )
        }
        if (['0', 'off', 'desativar'].includes(arg)) {
            setAP(from, false)
            return escrever(`❌ *Anti-Porno DESATIVADO*`)
        }
        const { g } = grupos.getGrupo(from)
        const st = g.antiporno ? '🟢 ATIVO' : '🔴 DESATIVADO'
        await escrever(
            `┌─「🔞 𝐀𝐍𝐓𝐈-𝐏𝐎𝐑𝐍𝐎 」\n│ Status: *${st}*\n└────────────\n\n` +
            `✧ ${p}antiporno 1 — ativar\n✧ ${p}antiporno 0 — desativar`
        )
    } catch (e) {
        await escrever('❌ ' + (e.message || e))
    }
}
