const antipv = require('../lib/antipv')
const config = require('../lib/config')

module.exports = async (client, info, args, ctx) => {
    const { escrever, reagir, isDono, prefix, texto } = ctx || {}
    if (!isDono) return escrever('❌ Só *dono* / *sub dono*.')

    try { await reagir(ctx.from, '📵') } catch {}

    const arg = (texto || (args || []).join(' ') || '').trim().toLowerCase()
    const p = prefix || '/'

    if (arg === '1' || arg === 'on' || arg === 'ativar') {
        antipv.setAntipv(true)
        return escrever(`✔️ *AntiPV ATIVADO*\nO bot *não responde comandos no privado*.\n\nDesativar: *${p}antipv 0*`)
    }
    if (arg === '0' || arg === 'off' || arg === 'desativar') {
        antipv.setAntipv(false)
        return escrever(`❌ *AntiPV DESATIVADO*\nComandos no PV liberados de novo.`)
    }

    const st = antipv.get()
    const status = st.antipv ? '🟢 ATIVO' : '🔴 DESATIVADO'
    await escrever(
        `┌─「📵 𝐀𝐍𝐓𝐈𝐏𝐕 」\n` +
        `│ Status: *${status}*\n` +
        `└────────────\n\n` +
        `Quando *ativo*, o bot *ignora comandos no privado*\n` +
        `(grupos continuam normais).\n\n` +
        `✧ ${p}antipv 1 — ativar\n` +
        `✧ ${p}antipv 0 — desativar`
    )
}
