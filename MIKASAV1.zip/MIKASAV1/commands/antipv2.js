const antipv = require('../lib/antipv')
const config = require('../lib/config')

const CONTATO_DEV = '558496762508'
const LINK_WA = `https://wa.me/${CONTATO_DEV}`

module.exports = async (client, info, args, ctx) => {
    const { escrever, reagir, isDono, prefix, texto, from } = ctx || {}
    if (!isDono) return escrever('❌ Só *dono* / *sub dono*.')

    try { await reagir(from, '⚠️') } catch {}

    const arg = (texto || (args || []).join(' ') || '').trim().toLowerCase()
    const p = prefix || '/'

    if (arg === '1' || arg === 'on' || arg === 'ativar') {
        antipv.setAntipv2(true)
        return escrever(
            `✔️ *AntiPV2 ATIVADO*\n` +
            `No privado, estranhos recebem aviso + botão do dev.\n\n` +
            `Desativar: *${p}antipv2 0*`
        )
    }
    if (arg === '0' || arg === 'off' || arg === 'desativar') {
        antipv.setAntipv2(false)
        return escrever(`❌ *AntiPV2 DESATIVADO*`)
    }

    const st = antipv.get()
    const status = st.antipv2 ? '🟢 ATIVO' : '🔴 DESATIVADO'
    await escrever(
        `┌─「⚠️ 𝐀𝐍𝐓𝐈𝐏𝐕𝟐 」\n` +
        `│ Status: *${status}*\n` +
        `└────────────\n\n` +
        `Quando *ativo*, mensagens no *privado* (não-dono) recebem:\n` +
        `aviso de “não legalizado” + botão wa.me do Edy.\n\n` +
        `✧ ${p}antipv2 1 — ativar\n` +
        `✧ ${p}antipv2 0 — desativar`
    )
}

module.exports.CONTATO_DEV = CONTATO_DEV
module.exports.LINK_WA = LINK_WA
module.exports.TEXTO_AVISO =
`> ⚠️ *AVISO* ⚠️
*Esta mensagem privada não foi legalizada pelo papai Edy, seu número será bloqueado automaticamente, para contatar o desenvolvedor clique no botão abaixo*`
