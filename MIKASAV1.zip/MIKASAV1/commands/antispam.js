const grupos = require('../lib/grupos')
const config = require('../lib/config')

module.exports = async (client, info, args, contexto) => {
    const { from, isAdmin, isDono, escrever, reagir, texto } = contexto
    const prefix = config.prefix()
    const foot = config.footer()

    if (!from.endsWith('@g.us')) return await escrever('❌ Só em grupos.')
    if (!isAdmin && !isDono) return await escrever('❌ Só admins.')

    const partes = (texto || args?.join?.(' ') || '').trim().toLowerCase().split(/\s+/)
    const arg = partes[0] || ''
    const limite = parseInt(partes[1], 10)

    if (arg === '1' || arg === 'on' || arg === 'ativar') {
        const lim = (limite > 0 && limite <= 30) ? limite : 5
        grupos.setAntispam(from, true, lim)
        return await escrever(`✔️ *Antispam ATIVADO*\nLimite: *${lim}* msgs / 10s\n\n${foot}`)
    }
    if (arg === '0' || arg === 'off' || arg === 'desativar') {
        grupos.setAntispam(from, false)
        return await escrever(`❌ *Antispam DESATIVADO*\n\n${foot}`)
    }

    const { g } = grupos.getGrupo(from)
    const status = g.antispam ? '🟢 ATIVO' : '🔴 DESATIVADO'
    try { await reagir(from, '🚫') } catch {}

    const caption = `┌─「⚔️𝐀𝐍𝐓𝐈𝐒𝐏𝐀𝐌⚔️ 」
│ Status: *${status}*
│ Limite: *${g.antispamLimite || 5}* msgs / 10s
└────────────

Excesso de mensagens rápidas = apaga + mute temporário.
Escolha abaixo:
${foot}`

    try {
        await client.sendMessage(from, {
            text: caption,
            footer: config.nomebot(),
            nativeFlow: [
                {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: '✔️ ATV Ativar',
                        id: `${prefix}antispam 1`
                    })
                },
                {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: '❌ DST Desativar',
                        id: `${prefix}antispam 0`
                    })
                }
            ]
        }, { quoted: info })
    } catch {
        await escrever(caption + `\n\n${prefix}antispam 1 — ativar\n${prefix}antispam 0 — desativar\n${prefix}antispam 1 5 — ativar com limite 5`)
    }
}
