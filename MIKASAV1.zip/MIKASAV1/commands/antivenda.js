const grupos = require('../lib/grupos')
const config = require('../lib/config')

module.exports = async (client, info, args, contexto) => {
    const { from, isAdmin, isDono, escrever, reagir, texto } = contexto
    const prefix = config.prefix()
    const foot = config.footer()

    if (!from.endsWith('@g.us')) return await escrever('❌ Só em grupos.')
    if (!isAdmin && !isDono) return await escrever('❌ Só admins.')

    const arg = (texto || args?.[0] || '').trim().toLowerCase()
    if (arg === '1' || arg === 'on' || arg === 'ativar') {
        grupos.setAntivenda(from, true)
        return await escrever(`✔️ *Antivenda ATIVADO*\nPropagandas de venda serão apagadas.\n\n${foot}`)
    }
    if (arg === '0' || arg === 'off' || arg === 'desativar') {
        grupos.setAntivenda(from, false)
        return await escrever(`❌ *Antivenda DESATIVADO*\n\n${foot}`)
    }

    const { g } = grupos.getGrupo(from)
    const status = g.antivenda ? '🟢 ATIVO' : '🔴 DESATIVADO'
    try { await reagir(from, '🛒') } catch {}

    const caption = `┌─「⚔️𝐀𝐍𝐓𝐈𝐕𝐄𝐍𝐃𝐀⚔️ 」
│ Status: *${status}*
└────────────

Bloqueia mensagens de venda/propaganda.
Escolha abaixo:
${foot}`

    try {
        await client.sendMessage(from, {
            text: caption,
            footer: config.nomebot(),
            nativeFlow: [
                {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: '✔️ ATV Ativar',
                        id: `${prefix}antivenda 1`
                    })
                },
                {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: '❌ DST Desativar',
                        id: `${prefix}antivenda 0`
                    })
                }
            ]
        }, { quoted: info })
    } catch {
        await escrever(caption + `\n\n${prefix}antivenda 1 — ativar\n${prefix}antivenda 0 — desativar`)
    }
}
