const fs = require('fs')
const path = require('path')
const FILE = path.join(__dirname, '../data/antiword.json')
function load() { try { return JSON.parse(fs.readFileSync(FILE, 'utf8')) } catch { return {} } }
function save(d) { fs.mkdirSync(path.dirname(FILE), { recursive: true }); fs.writeFileSync(FILE, JSON.stringify(d, null, 2)) }
module.exports = async (client, info, args, ctx) => {
  if (!ctx.from.endsWith('@g.us')) return ctx.escrever('❌ Só grupos')
  if (!ctx.isAdmin && !ctx.isDono) return ctx.escrever('❌ Só admin')
  const arg = (args[0] || '').toLowerCase()
  const db = load()
  if (arg === '1' || arg === 'on') { db[ctx.from] = { on: true, words: db[ctx.from]?.words || [] }; save(db); return ctx.escrever('✅ Antiword ON') }
  if (arg === '0' || arg === 'off') { db[ctx.from] = { on: false, words: db[ctx.from]?.words || [] }; save(db); return ctx.escrever('✅ Antiword OFF') }
  if (arg === 'add' && args[1]) {
    db[ctx.from] = db[ctx.from] || { on: true, words: [] }
    db[ctx.from].words.push(args.slice(1).join(' ').toLowerCase())
    save(db)
    return ctx.escrever('✅ Palavra adicionada')
  }
  await ctx.escrever('🚫 antiword 1/0 | antiword add palavra')
}
