const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *antonimo*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'antonimo*')+'\n\n'+config.footer())}
