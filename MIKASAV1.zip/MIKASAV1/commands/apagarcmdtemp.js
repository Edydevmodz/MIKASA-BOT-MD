module.exports = async (client, info, args, ctx) => {
  if (!ctx.isDono) return ctx.escrever('❌ Só dono')
  await ctx.escrever('👑 *apagarcmdtemp*\nFerramenta do dono disponível.\nUse com cuidado.')
}
