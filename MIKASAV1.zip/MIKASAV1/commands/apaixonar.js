const { enviarAcaoGif } = require("../lib/gifAction")
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: "apaixonar",
        emoji: "😍",
        frase: "se apaixonou por {alvo}",
        gifQuery: "anime love eyes",
        precisaAlvo: true,
        args
    })
}
