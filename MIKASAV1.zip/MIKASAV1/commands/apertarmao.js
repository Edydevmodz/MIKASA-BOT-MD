const { enviarAcaoGif } = require('../lib/gifAction')
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: 'apertarmao',
        emoji: '🤝',
        frase: 'apertou a mão de {alvo}',
        gifQuery: 'anime handshake',
        precisaAlvo: true,
        args
    })
}
