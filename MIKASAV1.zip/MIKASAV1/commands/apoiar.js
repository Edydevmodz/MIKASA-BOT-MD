const { enviarAcaoGif } = require('../lib/gifAction')
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: 'apoiar',
        emoji: '💪',
        frase: 'apoiou {alvo}',
        gifQuery: 'anime support gif',
        precisaAlvo: true,
        args
    })
}
