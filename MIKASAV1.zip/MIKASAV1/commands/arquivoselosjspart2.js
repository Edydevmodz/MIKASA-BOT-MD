module.exports = require('./arquivo_selos_js_part_2.js')
