const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *ascendente*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'ascendente*')+'\n\n'+config.footer())}
