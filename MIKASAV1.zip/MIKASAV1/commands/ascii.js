module.exports = async (client, info, args, ctx) => {
  const q = (ctx.texto || args.join(' ') || 'MIKASA').slice(0, 20)
  await ctx.escrever('```\n' + q + '\n' + '='.repeat(q.length) + '\n```')
}
