const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *ascii code*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'ascii_code*')+'\n\n'+config.footer())}
