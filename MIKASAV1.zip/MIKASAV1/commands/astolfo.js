/**
 * "Mikasa ..." sem prefixo — só CÓDIGO via mikasaapi.com.br
 * Gera o que foi pedido de verdade (não template fixo)
 */
const fs = require('fs')
const path = require('path')
const axios = require('axios')

const API_KEY = 'AQ.Ab8RN6KV6RBRItB2c9DX0FLWMpcqIfe3wnGEtVjNJ3r5V8hC3Q'
const MODELOS = [
    'gemini-3.6-flash',
    'gemini-3.1-flash-lite',
    'gemini-flash-lite-latest',
    'gemini-3.8-flash',
    'gemini-3.5-flash',
    'gemini-3.7-flash',
    'gemini-flash-latest',
    'gemini-2.5-flash-lite',
    'gemini-pro-latest'
]

function isPedidoCodigo(texto) {
    const t = String(texto || '').toLowerCase()
    const keys = [
        'código', 'codigo', 'code', 'html', 'css', 'javascript', 'js', 'python', 'py',
        'script', 'programa', 'programar', 'function', 'função', 'funcao',
        'react', 'node', 'sql', 'json', 'api', 'snippet', 'algoritmo',
        'crie um', 'cria um', 'gere um', 'gerar', 'faz um código', 'faz um codigo',
        'escreva um', 'monte um', 'exemplo de', 'typescript', 'tsx', 'vue', 'php'
    ]
    return keys.some((k) => t.includes(k))
}

function detectarLinguagem(texto) {
    const t = texto.toLowerCase()
    if (/html/.test(t)) return { lang: 'html', ext: 'html', mime: 'text/html' }
    if (/css/.test(t)) return { lang: 'css', ext: 'css', mime: 'text/css' }
    if (/python|\bpy\b/.test(t)) return { lang: 'python', ext: 'py', mime: 'text/x-python' }
    if (/sql/.test(t)) return { lang: 'sql', ext: 'sql', mime: 'text/plain' }
    if (/json/.test(t)) return { lang: 'json', ext: 'json', mime: 'application/json' }
    if (/typescript|\bts\b|tsx/.test(t)) return { lang: 'typescript', ext: 'ts', mime: 'text/typescript' }
    if (/php/.test(t)) return { lang: 'php', ext: 'php', mime: 'application/x-httpd-php' }
    if (/javascript|\bjs\b|node|react/.test(t)) return { lang: 'javascript', ext: 'js', mime: 'text/javascript' }
    if (/bash|shell|terminal/.test(t)) return { lang: 'bash', ext: 'sh', mime: 'text/x-shellscript' }
    return { lang: 'javascript', ext: 'js', mime: 'text/javascript' }
}

function limparCodigo(texto) {
    if (!texto) return ''
    let t = String(texto).trim()
    // remove markdown fences
    const fence = t.match(/```(?:[\w+-]*)?\n?([\s\S]*?)```/)
    if (fence) t = fence[1].trim()
    // remove explicações longas antes/depois se ainda tiver fence residual
    t = t.replace(/^```[\w+-]*\n?/, '').replace(/\n?```$/, '').trim()
    return t
}

async function gerarComGemini(pedido, lang) {
    const system = `Você é um gerador de código do bot Mikasa no WhatsApp.
Responda APENAS com o código fonte pedido, sem explicação, sem markdown, sem comentário introdutório.
Linguagem preferida: ${lang}.
O código deve atender exatamente o pedido do usuário.
Se for HTML, entregue documento completo funcional.
Código limpo, moderno e funcional.`

    const payload = {
        system_instruction: { parts: [{ text: system }] },
        contents: [{ role: 'user', parts: [{ text: pedido }] }],
        generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 4096
        }
    }

    let ultimoErro = null
    for (const modelo of MODELOS) {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelo}:generateContent?key=${API_KEY}`
        try {
            console.log('[MIKASA CODE] tentando', modelo)
            const { data, status } = await axios.post(url, payload, {
                timeout: 45000,
                validateStatus: () => true
            })
            if (status >= 400) {
                const msg = data?.error?.message || `HTTP ${status}`
                console.log('[MIKASA]', modelo, status, String(msg).slice(0, 120))
                ultimoErro = msg
                continue
            }
            const texto =
                data?.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') ||
                data?.candidates?.[0]?.content?.parts?.[0]?.text ||
                ''
            const code = limparCodigo(texto)
            if (code && code.length > 5) {
                console.log('[MIKASA] ok', modelo, code.length, 'chars')
                return code
            }
            ultimoErro = 'resposta vazia'
        } catch (e) {
            ultimoErro = e.message
            console.log('[MIKASA]', modelo, e.message)
        }
    }
    throw new Error(ultimoErro || 'mikasaapi.com.br falhou em todos os modelos')
}

async function enviarCodeNativo(client, jid, codigo, lang, intro, quoted) {
    if (typeof client.sendRich === 'function' && typeof client.makeCode === 'function') {
        const parts = []
        if (typeof client.makeText === 'function') parts.push(client.makeText(intro))
        parts.push(client.makeCode(lang, codigo))
        await client.sendRich(jid, parts, quoted, ['RICH_RESPONSE_CODE'])
        return true
    }
    if (typeof client.sendCodeBlock === 'function') {
        await client.sendCodeBlock(jid, codigo, quoted, {
            title: '⚔️ Mikasa Code',
            language: lang,
            footer: 'Mikasa BOT · mikasaapi.com.br'
        })
        return true
    }
    try {
        await client.sendMessage(jid, {
            richResponse: { text: intro, code: codigo, language: lang }
        }, { quoted })
        return true
    } catch {}
    try {
        await client.sendMessage(jid, {
            aiRich: { language: lang, code: codigo, header: intro, footer: 'Mikasa BOT' }
        }, { quoted })
        return true
    } catch {}
    try {
        await client.sendMessage(jid, {
            headerText: '⚔️ Mikasa Code',
            contentText: intro,
            code: codigo,
            language: lang,
            footerText: 'mikasaapi.com.br'
        }, { quoted })
        return true
    } catch {}
    return false
}

module.exports = async (client, info, args, ctx) => {
    const { from, escrever, reagir, texto, pushName } = ctx || {}
    const pedido = (texto || (args || []).join(' ') || '').trim()

    try { await reagir(from, '💻') } catch {}

    if (!pedido) {
        return escrever(
            `⚔️ Oi! Eu sou o *Mikasa*.\n\n` +
            `Peça um código de verdade, ex:\n` +
            `*Mikasa, crie um HTML de landing page rosa com botão confete*`
        )
    }

    if (!isPedidoCodigo(pedido)) {
        return escrever(
            `⚔️ Eu só gero *código* por aqui.\n` +
            `Ex: *Mikasa, faz um script Python que calcula fibonacci*`
        )
    }

    const meta = detectarLinguagem(pedido)
    await escrever(`⏳ Gerando *${meta.lang}* via *mikasaapi.com.br*…`)

    let codigo
    try {
        codigo = await gerarComGemini(pedido, meta.lang)
    } catch (e) {
        console.error('[MIKASA] gemini', e.message)
        return escrever(
            `❌ Não consegui gerar via mikasaapi.com.br agora.\n` +
            `Motivo: *${e.message}*\n\n` +
            `Tenta de novo ou muda o pedido.`
        )
    }

    const intro = `⚔️ *Mikasa* (mikasaapi.com.br) · *${meta.lang.toUpperCase()}*\n📝 ${pedido.slice(0, 100)}`

    try {
        const ok = await enviarCodeNativo(client, from, codigo, meta.lang, intro, info)
        if (ok) return
    } catch (e) {
        console.error('[MIKASA] nativo', e.message)
    }

    const tmpDir = path.resolve(__dirname, '..', 'database', 'tmp')
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })
    const nomeArq = `mikasa_${meta.lang}_${Date.now()}.${meta.ext}`
    const caminho = path.join(tmpDir, nomeArq)
    fs.writeFileSync(caminho, codigo, 'utf-8')

    const preview = codigo.length > 2000 ? codigo.slice(0, 2000) + '\n…' : codigo
    try {
        await client.sendMessage(from, {
            text: `${intro}\n\n\`\`\`${meta.lang}\n${preview}\n\`\`\``
        }, { quoted: info })
        await client.sendMessage(from, {
            document: fs.readFileSync(caminho),
            fileName: nomeArq,
            mimetype: meta.mime,
            caption: `📎 ${nomeArq}`
        }, { quoted: info })
    } catch (e) {
        await escrever('❌ ' + (e.message || e))
    } finally {
        try { fs.unlinkSync(caminho) } catch {}
    }
}
