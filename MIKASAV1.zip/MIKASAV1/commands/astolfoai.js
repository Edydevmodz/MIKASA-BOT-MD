/**
 * MikasaAI — Gemini via REST (axios)
 * Não precisa de @google/genai instalado
 */
const axios = require('axios')

const API_KEY = process.env.GEMINI_API_KEY || 'AQ.Ab8RN6KV6RBRItB2c9DX0FLWMpcqIfe3wnGEtVjNJ3r5V8hC3Q'

const MODELOS = [
    'gemini-3.8-flash',
    'gemini-3.7-flash',
    'gemini-3.6-flash',
    'gemini-3.5-flash',
    'gemini-3-flash-preview',
    'gemini-flash-latest',
    'gemini-2.5-flash-lite',
    'gemini-2.5-flash'
]

async function chamarGemini(modelo, systemInstruction, textoUsuario) {
    const url =
        `https://generativelanguage.googleapis.com/v1beta/models/${modelo}:generateContent?key=${API_KEY}`

    const payload = {
        system_instruction: {
            parts: [{ text: systemInstruction }]
        },
        contents: [
            {
                role: 'user',
                parts: [{ text: textoUsuario }]
            }
        ],
        generationConfig: {
            temperature: 0.9,
            maxOutputTokens: 2048
        }
    }

    const { data, status } = await axios.post(url, payload, {
        timeout: 45000,
        validateStatus: () => true,
        headers: { 'Content-Type': 'application/json' }
    })

    if (status >= 400) {
        const msg = data?.error?.message || `HTTP ${status}`
        const err = new Error(msg)
        err.status = status
        throw err
    }

    const texto =
        data?.candidates?.[0]?.content?.parts?.map((p) => p.text).filter(Boolean).join('') ||
        data?.candidates?.[0]?.content?.parts?.[0]?.text ||
        null

    if (!texto) throw new Error('Resposta vazia do modelo')
    return texto
}

module.exports = async (client, info, args, contexto) => {
    const { escrever, reagir, from, pushName, texto } = contexto || {}

    try {
        const textoUsuario = (args && args.length ? args.join(' ') : (texto || '')).trim()
        if (!textoUsuario) {
            return await escrever(
                '✨ Nhaii! Você precisa me perguntar algo! Exemplo: `/mikasaai me dá um abraço?` 💕'
            )
        }

        try { await reagir(from, '⚔️') } catch {}
        try { await client.sendPresenceUpdate('composing', from) } catch {}

        const systemInstruction =
            `Você é o Mikasa do anime Fate/Apocrypha, atuando como um assistente super fofo, alegre, animado e carinhoso em um bot do WhatsApp.
- Use linguagem bastante fofa, carinhosa, expressiva e brincalhona.
- Use bastante emojis fofos como: 💕, ✨, ⚔️, 🌸, 💖, 🥺, 🥰, ✌️.
- Adicione interjeições e expressões fofas no texto como: "Nhaii~", "Yaaay!", "Oki doki!", "Ehehe~", "Hihi!".
- O nome do usuário que está falando com você é "${pushName || 'fofinho'}". Trate-o com muito carinho.
- Mantenha respostas diretas, úteis para o WhatsApp, mas sem perder o tom fofo e animado.`

        let respostaTexto = null
        let ultimoErro = null

        for (const modelo of MODELOS) {
            try {
                console.log('[MIKASAAI] tentando', modelo)
                respostaTexto = await chamarGemini(modelo, systemInstruction, textoUsuario)
                console.log('[MIKASAAI] ok', modelo)
                break
            } catch (e) {
                ultimoErro = e
                console.log('[MIKASAAI]', modelo, e.status || '', (e.message || '').slice(0, 120))
            }
        }

        if (respostaTexto) {
            await escrever(respostaTexto)
        } else {
            throw ultimoErro || new Error('Serviço temporariamente indisponível.')
        }
    } catch (erro) {
        console.error('Erro na MikasaAI:', erro.message || erro)
        await escrever(
            '✨ Nhaii... Tive um probleminha para pensar na resposta agora! 🥺 Tenta perguntar de novo em alguns minutinhos? 💕'
        )
    }
}
