const axios = require('axios')
module.exports = async (client, info, args, ctx) => {
  try {
    const { data } = await axios.get('https://www.boredapi.com/api/activity', { timeout: 12000 })
    await ctx.escrever('🎯 ' + data.activity + '\nTipo: ' + data.type)
  } catch { await ctx.escrever('🎯 Leia um livro hoje!') }
}
