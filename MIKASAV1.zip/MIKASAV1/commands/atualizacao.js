module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto } = ctx || {}
  try { await reagir(from, '✨') } catch {}
  try {
    await escrever('✨ *Mikasa Update*\n📅 *14/10/2026* às *09:50*\n📦 +60 comandos\nDigite */menunovos*')
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
