const dl = require('../lib/downloader')
module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto, prefix } = ctx || {}
  const q = (texto || (args || []).join(' ') || '').trim()
  if (!q) return escrever('❌ Use: *' + (prefix||'/') + 'audioyt link ou nome*')
  try { await reagir(from, '📥') } catch {}
  await escrever('⏳ Baixando…')
  try {
    let res
    const kind = 'audioyt'
    if (kind === 'ytmp3' || kind === 'audioyt') res = await dl.youtubeDownload(q, 'mp3')
    else if (kind === 'ytmp4' || kind === 'videoyt' || kind === 'shortsyt') res = await dl.youtubeDownload(q, 'mp4')
    else if (kind === 'yt' || kind === 'play') {
      const t = /mp4/i.test(q) ? 'mp4' : 'mp3'
      const qq = q.replace(/^(mp3|mp4)\s*/i, '').trim() || q
      res = await dl.youtubeDownload(qq, t)
    }
    else if (kind === 'tiktok' || kind === 'ttk' || kind === 'ttsemmarca') res = await dl.tiktokDownload(q)
    else if (kind === 'spotify' || kind === 'spotifytrack' || kind === 'soundcloudtrack' || kind === 'deezertrack' || kind === 'applemusic')
      res = await dl.wrap(dl.downloadSpotify, q)
    else if (kind === 'instagram' || kind === 'igstory' || kind === 'igreels' || kind === 'igfoto' || kind === 'igvideo' || kind === 'baixarig')
      res = await dl.wrap(dl.downloadInstagram, q)
    else if (kind === 'facebook' || kind === 'fbhd' || kind === 'fbsd' || kind === 'fbreel' || kind === 'baixarfb')
      res = await dl.wrap(dl.downloadFacebook, q)
    else if (kind === 'twitter' || kind === 'baixartwitter')
      res = await dl.wrap(dl.downloadTwitter, q)
    else if (kind === 'pinterest' || kind === 'baixarpinterest' || kind === 'pinterestimg' || kind === 'pinterestvideo')
      res = await dl.wrap(dl.downloadPinterest, q)
    else if (kind === 'mediafire' || kind === 'baixarmf' || kind === 'mfinfo')
      res = await dl.wrap(dl.downloadMediafire, q)
    else if (kind === 'threads' || kind === 'baixarthreads')
      res = await dl.wrap(dl.downloadGeneric, 'threads', q)
    else if (kind === 'reddit' || kind === 'redditdl')
      res = await dl.wrap(dl.downloadGeneric, 'reddit', q)
    else if (kind === 'capcut' || kind === 'baixarcapcut')
      res = await dl.wrap(dl.downloadGeneric, 'capcut', q)
    else if (kind === 'pixeldrain' || kind === 'gdriveinfo')
      res = await dl.wrap(dl.downloadGeneric, kind.replace('info',''), q)
    else {
      res = await dl.youtubeDownload(q, 'mp3')
    }

    if (!res || !res.success || !res.url) {
      return escrever('❌ ' + ((res && res.error) || 'Não consegui baixar. Confira o link.'))
    }

    const caption = '📥 *' + (res.title || 'audioyt') + '*\n' + (res.channel ? '👤 ' + res.channel + '\n' : '')
    const url = res.url
    const isAudio = /mp3|audio/i.test(String(res.formato||'')) || kind === 'ytmp3' || kind === 'audioyt' || kind === 'spotify' || kind === 'play'
    const isImg = /\.(jpg|jpeg|png|webp)(\?|$)/i.test(url) || kind.includes('foto') || kind.includes('img') || kind === 'thumbyt'

    if (isAudio) {
      try {
        if (res.thumbnail) await client.sendMessage(from, { image: { url: res.thumbnail }, caption }, { quoted: info })
      } catch {}
      try {
        await client.sendMessage(from, { audio: { url }, mimetype: 'audio/mpeg', fileName: 'audio.mp3' }, { quoted: info })
      } catch {
        const buf = await dl.baixarBuffer(url)
        await client.sendMessage(from, { audio: buf, mimetype: 'audio/mpeg' }, { quoted: info })
      }
    } else if (isImg) {
      await client.sendMessage(from, { image: { url }, caption }, { quoted: info })
    } else {
      try {
        const buf = await dl.baixarBuffer(url)
        await client.sendMessage(from, { video: buf, mimetype: 'video/mp4', caption }, { quoted: info })
      } catch {
        await client.sendMessage(from, { video: { url }, caption }, { quoted: info })
      }
    }
    await escrever('✅ Enviado!')
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
