module.exports = require('./auto_apresentar.js')
