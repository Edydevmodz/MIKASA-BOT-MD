module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto, prefix, info: inf } = ctx || {}
  const remetenteJid = info?.key?.participant || info?.key?.remoteJid
  try { await reagir(from, '✨') } catch {}
  try {
    const q=(texto||'').trim();if(!q)return escrever('❌ /aviso_grupo texto');await escrever('┌─「📢 𝐀𝐕𝐈𝐒𝐎 」\n│ '+q.replace(/\n/g,'\n│ ')+'\n└────────────')
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
