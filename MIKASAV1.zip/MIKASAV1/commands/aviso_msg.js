module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto } = ctx || {}
  try { await reagir(from, '✨') } catch {}
  try {
    const q = (texto || '').trim()
    if (!q) return escrever('❌ /aviso_msg texto')
    await escrever('┌─「📢 𝐀𝐕𝐈𝐒𝐎 」\n│ ' + q + '\n└────────────')
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
