const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args[0]||'').trim();
if(!q)return ctx.escrever('❌ Link\n*'+config.prefix()+'baixar_facebook url*');
await ctx.escrever('📥 *baixar facebook*\n'+q+'\n'+config.footer())}
