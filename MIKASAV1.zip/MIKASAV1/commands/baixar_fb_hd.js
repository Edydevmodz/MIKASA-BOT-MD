const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args[0]||'').trim();
if(!q)return ctx.escrever('❌ Link\n*'+config.prefix()+'baixar_fb_hd url*');
await ctx.escrever('📥 *baixar fb hd*\n'+q+'\n'+config.footer())}
