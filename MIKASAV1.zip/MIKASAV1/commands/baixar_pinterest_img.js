const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args[0]||'').trim();
if(!q)return ctx.escrever('❌ Link\n*'+config.prefix()+'baixar_pinterest_img url*');
await ctx.escrever('📥 *baixar pinterest img*\n'+q+'\n'+config.footer())}
