const fs = require('fs')
const path = require('path')
const msgLogger = require('../lib/msgLogger')

module.exports = async (client, info, args, ctx) => {
    const { from, escrever, isDono } = ctx
    if (!isDono) return escrever('❌ Só dono')
    if (!from.endsWith('@g.us')) return escrever('❌ Use no grupo que quer exportar.')

    const lista = msgLogger.listar(from, { limite: 500 })
    if (!lista.length) return escrever('📭 Sem logs neste grupo.')

    const tmp = path.resolve(__dirname, '..', 'database', `export_${Date.now()}.json`)
    fs.writeFileSync(tmp, JSON.stringify(lista, null, 2), 'utf-8')
    try {
        await client.sendMessage(from, {
            document: fs.readFileSync(tmp),
            fileName: `msglogs_${from.split('@')[0]}.json`,
            mimetype: 'application/json',
            caption: `📋 Export de *${lista.length}* mensagens salvas.`
        }, { quoted: info })
    } finally {
        try { fs.unlinkSync(tmp) } catch {}
    }
}
