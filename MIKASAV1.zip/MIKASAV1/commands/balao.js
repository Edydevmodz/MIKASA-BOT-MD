const grupos = require('../lib/grupos')
const config = require('../lib/config')
const { acaoGif } = require('../lib/gifaction')
module.exports = async (client, info, args, contexto) => {
    const { from, escrever } = contexto
    contexto.args = args
    if (from.endsWith('@g.us') && !grupos.brincadeirasAtivas(from)) {
        return await escrever('🚫 Brincadeiras suspensas neste grupo.\nAdmin: *' + config.prefix() + 'brincadeiras 1*')
    }
    await acaoGif(client, info, contexto, {
        emoji: '🎈',
        queryGif: 'balloon',
        frase: '{eu} deu um balão pra {alvo} 🎈' + '\n\n' + config.footer(),
        precisaAlvo: true,
        exemplo: config.prefix() + 'balao @user'
    })
}
