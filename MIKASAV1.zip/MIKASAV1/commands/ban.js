module.exports = async (client, info, args, contexto) => {
    const { from, isBotAdmin, isAdmin, escrever } = contexto

    if (!from.endsWith('@g.us')) return await escrever('❌ Este comando só funciona em grupos!')
    if (!isAdmin) return await escrever('❌ Apenas administradores podem usar este comando.')
    if (!isBotAdmin) return await escrever('❌ Preciso de admin para remover membros.')

    let alvo = null
    const ctx = info?.message?.extendedTextMessage?.contextInfo || {}

    if (ctx.mentionedJid?.[0]) alvo = ctx.mentionedJid[0]
    else if (ctx.participant) alvo = ctx.participant
    else if (args[0]) alvo = args[0].replace(/\D/g, '') + '@s.whatsapp.net'

    if (!alvo) return await escrever('❌ Marque alguém ou responda a mensagem de quem deseja banir.')

    try {
        await client.groupParticipantsUpdate(from, [alvo], 'remove')
        await escrever(`🚨 @${alvo.split('@')[0]} foi removido com sucesso.`)
    } catch (e) {
        await escrever('❌ Erro ao tentar remover o membro.')
    }
}
