const axios = require('axios')
const config = require('../lib/config')
module.exports = async (client, info, args, ctx) => {
  const cod = (ctx.texto || args[0] || '').replace(/\D/g, '')
  if (!cod) return ctx.escrever('❌ *' + config.prefix() + 'banco 001*')
  try {
    const { data } = await axios.get('https://brasilapi.com.br/api/banks/v1/' + cod, { timeout: 15000 })
    await ctx.escrever('🏦 *' + data.name + '*\nCódigo: ' + data.code + '\nISPB: ' + data.ispb + '\n' + config.footer())
  } catch (e) { await ctx.escrever('❌ Banco não encontrado') }
}
