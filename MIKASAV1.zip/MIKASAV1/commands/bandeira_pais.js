const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *bandeira pais*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'bandeira_pais*')+'\n\n'+config.footer())}
