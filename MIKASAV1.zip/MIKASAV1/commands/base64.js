module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto } = ctx || {}
  try { await reagir(from, '✨') } catch {}
  try {
    const q = (texto || '').trim()
    if (!q) return escrever('❌')
    await escrever(Buffer.from(q).toString('base64'))
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
