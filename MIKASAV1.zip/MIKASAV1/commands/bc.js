module.exports = require('./transmitir')
