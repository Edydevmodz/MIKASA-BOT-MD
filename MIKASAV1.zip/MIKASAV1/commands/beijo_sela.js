const { enviarAcaoGif } = require("../lib/gifAction")
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: "beijo_sela",
        emoji: "💋",
        frase: "selou um beijo em {alvo}",
        gifQuery: "anime kiss",
        precisaAlvo: true,
        args
    })
}
