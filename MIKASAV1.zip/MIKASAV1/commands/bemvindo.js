module.exports = require('./bem_vindo.js')
