module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto, prefix, info: inf } = ctx || {}
  const remetenteJid = info?.key?.participant || info?.key?.remoteJid
  try { await reagir(from, '✨') } catch {}
  try {
    await escrever('👋 *Bem-vindo(a)!*\nLeia as regras e se apresente.\nUse /menu para comandos.')
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
