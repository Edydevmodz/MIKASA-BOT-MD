module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto } = ctx || {}
  try { await reagir(from, '✨') } catch {}
  try {
    const q = (texto || '').trim()
    if (!q) return escrever('❌')
    await escrever(q.split('').map(c => c.charCodeAt(0).toString(2).padStart(8,'0')).join(' '))
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
