const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *bingo numero*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'bingo_numero*')+'\n\n'+config.footer())}
