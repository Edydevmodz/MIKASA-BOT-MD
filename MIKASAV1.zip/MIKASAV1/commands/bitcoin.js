const axios = require('axios')
const config = require('../lib/config')
module.exports = async (client, info, args, ctx) => {
  const { data } = await axios.get('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=brl,usd', { timeout: 15000 })
  await ctx.escrever('₿ BTC R$ ' + data.bitcoin.brl + ' | $' + data.bitcoin.usd + '\nΞ ETH R$ ' + data.ethereum.brl + '\n\n' + config.footer())
}
