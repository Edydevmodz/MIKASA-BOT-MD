const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *bitcoin hoje*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'bitcoin_hoje*')+'\n\n'+config.footer())}
