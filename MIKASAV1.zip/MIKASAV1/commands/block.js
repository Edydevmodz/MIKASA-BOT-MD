module.exports=async(client,info,args,ctx)=>{
if(!ctx.isDono)return ctx.escrever('❌ Só dono');
const n=(args[0]||'').replace(/\D/g,'');
if(!n)return ctx.escrever('❌ Número');
await client.updateBlockStatus(n+'@s.whatsapp.net','block');
await ctx.escrever('🚫 Bloqueado');
};