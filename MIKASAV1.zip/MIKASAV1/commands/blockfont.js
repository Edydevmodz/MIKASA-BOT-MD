const grupos = require('../lib/grupos')

module.exports = async (client, info, args, ctx) => {
    const { from, isAdmin, isDono, escrever, reagir, texto, prefix } = ctx || {}
    if (!from.endsWith('@g.us')) return escrever('❌ Só em grupos.')
    if (!isAdmin && !isDono) return escrever('❌ Só admin/dono.')
    try { await reagir(from, '🔤') } catch {}

    const arg = (texto || (args || []).join(' ') || '').trim().toLowerCase()
    const p = prefix || '/'

    if (['1', 'on', 'ativar'].includes(arg)) {
        grupos.setBlockfont(from, true)
        return escrever('✔️ *BlockFont ATIVADO*\nTextos com fonte especial serão apagados (sem marcar a msg).')
    }
    if (['0', 'off', 'desativar'].includes(arg)) {
        grupos.setBlockfont(from, false)
        return escrever('❌ *BlockFont DESATIVADO*')
    }
    const { g } = grupos.getGrupo(from)
    const st = g.blockfont ? '🟢 ATIVO' : '🔴 OFF'
    await escrever(
        `┌─「🔤 𝐁𝐋𝐎𝐂𝐊𝐅𝐎𝐍𝐓 」\n│ Status: *${st}*\n└────────────\n\n` +
        `✧ ${p}blockfont 1 — ativar\n✧ ${p}blockfont 0 — desativar`
    )
}
