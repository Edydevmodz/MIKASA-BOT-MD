const { enviarAcaoGif } = require("../lib/gifAction")
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: "boa_noite",
        emoji: "🌙",
        frase: "desejou boa noite pra {alvo}",
        gifQuery: "anime good night",
        precisaAlvo: true,
        args
    })
}
