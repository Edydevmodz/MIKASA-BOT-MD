const { enviarAcaoGif } = require("../lib/gifAction")
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: "bom_dia",
        emoji: "☀️",
        frase: "desejou bom dia pra {alvo}",
        gifQuery: "anime good morning",
        precisaAlvo: true,
        args
    })
}
