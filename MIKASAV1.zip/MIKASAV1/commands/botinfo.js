module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto, prefix, info: inf } = ctx || {}
  const remetenteJid = info?.key?.participant || info?.key?.remoteJid
  try { await reagir(from, '✨') } catch {}
  try {
    await escrever('🤖 *Mikasa BOT*\nNode: '+process.version+'\nPID: '+process.pid+'\nPlataforma: '+process.platform)
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
