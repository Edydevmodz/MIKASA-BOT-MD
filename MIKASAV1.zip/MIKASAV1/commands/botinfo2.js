module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto } = ctx || {}
  try { await reagir(from, '✨') } catch {}
  try {
    await escrever('🤖 *Mikasa BOT*\nNode ' + process.version + '\nPID ' + process.pid)
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
