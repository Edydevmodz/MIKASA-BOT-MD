const grupos = require('../lib/grupos')
const config = require('../lib/config')

module.exports = async (client, info, args, contexto) => {
    const { from, isAdmin, isDono, escrever, reagir } = contexto
    const prefix = config.prefix()
    const foot = config.footer()

    if (!from.endsWith('@g.us')) return await escrever('❌ Só funciona em grupos.')
    if (!isAdmin && !isDono) return await escrever('❌ Apenas administradores.')

    const arg = (args[0] || '').trim()

    if (arg !== '0' && arg !== '1') {
        const { g } = grupos.getGrupo(from)
        const status = g.brincadeiras !== false ? '🟢 ATIVADAS' : '🔴 SUSPENSAS'
        return await escrever(`🎮 *Brincadeiras:* ${status}\n\nPara ativar: *${prefix}brincadeiras 1*\nPara suspender: *${prefix}brincadeiras 0*\n\n${foot}`)
    }

    try { await reagir(from, arg === '1' ? '🎮' : '🚫') } catch {}

    grupos.setBrincadeiras(from, arg === '1')

    if (arg === '1') {
        await escrever(`🟢 *Brincadeiras ativadas!*\nComandos como mamar, namoro e o menubrincadeiras funcionam normalmente.\n\n${foot}`)
    } else {
        await escrever(`🔴 *Brincadeiras suspensas!*\nComandos de diversão e o menubrincadeiras ficam bloqueados neste grupo.\n\n${foot}`)
    }
}
