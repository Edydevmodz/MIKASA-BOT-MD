module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto } = ctx || {}
  try { await reagir(from, '✨') } catch {}
  try {
    await escrever('👋 *Bem-vindo(a)!*\nLeia as regras e use /menu')
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
