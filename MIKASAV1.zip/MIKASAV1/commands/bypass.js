/**
 * /bypass <link>
 * Bypass encurtadores / Linkvertise / key Delta
 * 1) Métodos FREE (sem key)
 * 2) zone.api.br se tiver key no settings (opcional)
 */
'use strict'

const https = require('https')
const http = require('http')
const { URL } = require('url')

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'

function botName() {
  try {
    const c = require('../lib/config')
    if (typeof c.botName === 'function') return c.botName()
    if (typeof c.nomebot === 'function') return c.nomebot()
  } catch {}
  return 'Mikasa BOT'
}

function zoneKey() {
  try {
    const s = require('../settings/settings.js')
    return s.zoneApiKey || s.ZONE_API_KEY || s.apis?.zone || ''
  } catch {
    return ''
  }
}

function extrairUrl(texto) {
  const t = String(texto || '').trim()
  if (!t) return null
  const m = t.match(/https?:\/\/[^\s<>"']+/i)
  if (m) return m[0].replace(/[),.;]+$/, '')
  if (/^[a-z0-9.-]+\.[a-z]{2,}\/\S+/i.test(t)) return 'https://' + t
  return null
}

function validarUrl(u) {
  try {
    const x = new URL(u)
    return x.protocol === 'http:' || x.protocol === 'https:'
  } catch {
    return false
  }
}

function httpJson(url, opts) {
  opts = opts || {}
  return new Promise((resolve, reject) => {
    let u
    try {
      u = new URL(url)
    } catch (e) {
      return reject(e)
    }
    const lib = u.protocol === 'https:' ? https : http
    const body = opts.body ? Buffer.from(opts.body) : null
    const headers = Object.assign(
      {
        'User-Agent': UA,
        Accept: 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9'
      },
      opts.headers || {}
    )
    if (body) {
      headers['Content-Type'] = opts.contentType || 'application/json'
      headers['Content-Length'] = body.length
    }
    const req = lib.request(
      {
        protocol: u.protocol,
        hostname: u.hostname,
        port: u.port || (u.protocol === 'https:' ? 443 : 80),
        path: u.pathname + u.search,
        method: opts.method || 'GET',
        headers,
        timeout: 25000,
        rejectUnauthorized: false
      },
      (res) => {
        const chunks = []
        res.on('data', (c) => chunks.push(c))
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8')
          let json = null
          try {
            json = JSON.parse(raw)
          } catch {}
          resolve({
            status: res.statusCode || 0,
            headers: res.headers || {},
            raw,
            json,
            location: res.headers.location || res.headers.Location
          })
        })
      }
    )
    req.on('error', reject)
    req.on('timeout', () => {
      req.destroy()
      reject(new Error('timeout'))
    })
    if (body) req.write(body)
    req.end()
  })
}

function httpText(url, method) {
  return httpJson(url, { method: method || 'GET' })
}

function extrairRedirectHtml(html, base) {
  if (!html) return null
  const patterns = [
    /<meta[^>]+http-equiv=["']?refresh["']?[^>]+content=["']?\d+\s*;\s*url=([^"'>\s]+)/i,
    /window\.location(?:\.href)?\s*=\s*["']([^"']+)["']/i,
    /location\.replace\(["']([^"']+)["']\)/i
  ]
  for (let i = 0; i < patterns.length; i++) {
    const m = html.match(patterns[i])
    if (m && m[1]) {
      try {
        return new URL(m[1].replace(/&amp;/g, '&'), base).href
      } catch {}
    }
  }
  return null
}

async function seguirRedirects(startUrl, max) {
  max = max || 10
  const cadeia = [startUrl]
  let atual = startUrl
  for (let i = 0; i < max; i++) {
    let res
    try {
      res = await httpText(atual, 'GET')
    } catch {
      break
    }
    if (res.status >= 300 && res.status < 400 && res.location) {
      try {
        const next = new URL(res.location, atual).href
        if (cadeia[cadeia.length - 1] === next) break
        cadeia.push(next)
        atual = next
        continue
      } catch {
        break
      }
    }
    const nextHtml = extrairRedirectHtml(res.raw || '', atual)
    if (nextHtml && cadeia.indexOf(nextHtml) === -1) {
      cadeia.push(nextHtml)
      atual = nextHtml
      continue
    }
    break
  }
  return { final: atual, cadeia }
}

/** linkvertise.com → linkvertise.lol (método free documentado) */
function linkvertiseLol(url) {
  try {
    const u = new URL(url)
    const hosts = [
      'linkvertise.com',
      'link-to.net',
      'link-hub.net',
      'link-target.net',
      'link-target.org',
      'link-center.net',
      'direct-link.net',
      'up-to-down.net',
      'file-link.net'
    ]
    if (hosts.some((h) => u.hostname.endsWith(h))) {
      u.hostname = 'linkvertise.lol'
      return u.href
    }
  } catch {}
  return null
}

function pegarResultadoApi(json, raw) {
  if (!json && !raw) return null
  if (typeof json === 'string' && /^https?:\/\//i.test(json)) return json
  if (json) {
    const cands = [
      json.result,
      json.link_final,
      json.final,
      json.destination,
      json.direct,
      json.url,
      json.data?.result,
      json.data?.url,
      json.data?.link,
      json.bypass,
      json.link
    ]
    for (const c of cands) {
      if (typeof c === 'string' && /^https?:\/\//i.test(c)) return c
      if (typeof c === 'string' && c.length > 8 && !/SHUT DOWN|error|join here/i.test(c)) {
        // pode ser KEY do Delta (não URL)
        if (!/\s/.test(c) && c.length < 200) return c
      }
    }
  }
  const m = String(raw || '').match(/https?:\/\/[^\s"'<>]+/g)
  if (m) {
    for (const u of m) {
      if (!/bypass\.vip\/discord|api\.bypass/i.test(u)) return u
    }
  }
  return null
}

/** tenta APIs free em sequência */
async function tentarApisFree(url) {
  const tentativas = [
    // bypass.vip free (pode estar off)
    async () => {
      const r = await httpJson(
        'https://api.bypass.vip/bypass?url=' + encodeURIComponent(url)
      )
      if (r.json && r.json.status === 'success') {
        const out = pegarResultadoApi(r.json, r.raw)
        if (out && !/SHUT DOWN|THANKS TO LEECHERS/i.test(out)) return { fonte: 'bypass.vip', out }
      }
      return null
    },
    // mirror comum
    async () => {
      const r = await httpJson(
        'https://bypass.vip/api/bypass?url=' + encodeURIComponent(url)
      )
      const out = pegarResultadoApi(r.json, r.raw)
      if (out && !/SHUT DOWN|error/i.test(String(out))) return { fonte: 'bypass.vip-web', out }
      return null
    },
    // linkvertise.lol swap + follow
    async () => {
      const lol = linkvertiseLol(url)
      if (!lol) return null
      const { final, cadeia } = await seguirRedirects(lol, 8)
      if (final && final !== url && final !== lol) {
        return { fonte: 'linkvertise.lol', out: final, cadeia }
      }
      // se a página lol devolve destino no HTML
      try {
        const page = await httpText(lol, 'GET')
        const dest = extrairRedirectHtml(page.raw, lol) || pegarResultadoApi(null, page.raw)
        if (dest && dest !== lol) return { fonte: 'linkvertise.lol-html', out: dest }
      } catch {}
      return null
    },
    // redirects nativos no original
    async () => {
      const { final, cadeia } = await seguirRedirects(url, 12)
      if (final && final !== url) return { fonte: 'redirect', out: final, cadeia }
      return null
    }
  ]

  for (const t of tentativas) {
    try {
      const r = await t()
      if (r && r.out) return r
    } catch {}
  }
  return null
}

async function tentarZone(url) {
  const key = zoneKey()
  if (!key) return null
  const bases = ['https://zone.api.br', 'https://zone.api.br/v2']
  const paths = [
    '/api/v1/bypass?url=' + encodeURIComponent(url) + '&apikey=' + encodeURIComponent(key),
    '/api/bypass?url=' + encodeURIComponent(url) + '&apikey=' + encodeURIComponent(key)
  ]
  for (const b of bases) {
    for (const p of paths) {
      try {
        const r = await httpJson(b + p)
        if (r.json && (r.json.status === true || r.json.status === 'success')) {
          const out =
            r.json.link_final ||
            r.json.result ||
            r.json.final ||
            r.json.url ||
            pegarResultadoApi(r.json, r.raw)
          if (out) return { fonte: 'zone.api.br', out }
        }
      } catch {}
    }
  }
  return null
}

function pareceKeyDelta(s) {
  const t = String(s || '').trim()
  if (/^https?:\/\//i.test(t)) return false
  // keys costumam ser alfanuméricas longas
  return /^[A-Za-z0-9_-]{12,120}$/.test(t)
}

async function run(client, info, args, ctx) {
  ctx = ctx || {}
  const from = ctx.from || (info && info.key && info.key.remoteJid)
  const prefix = ctx.prefix || '/'
  const nome = botName()
  const escrever =
    ctx.escrever ||
    (async function (t) {
      await client.sendMessage(from, { text: t }, { quoted: info })
    })
  const reagir = ctx.reagir || (async function () {})

  const raw = (ctx.texto || (args || []).join(' ') || '').trim()
  const url = extrairUrl(raw)

  if (!url) {
    return escrever(
      '🔗 *BYPASS* · Delta / Linkvertise\n\n' +
        'Informe o link da key.\n\n' +
        '✦ Ex: *' +
        prefix +
        'bypass https://linkvertise.com/...*\n\n' +
        '✦ Métodos free: redirect + linkvertise.lol\n' +
        '✦ Opcional: zoneApiKey no settings\n\n' +
        '• ' +
        nome
    )
  }

  if (!validarUrl(url)) {
    return escrever('❌ URL inválida. Use com https://\n\n• ' + nome)
  }

  try {
    await reagir(from, '🔗')
  } catch {}

  try {
    // 1) free
    let r = await tentarApisFree(url)
    // 2) zone se tiver key
    if (!r) r = await tentarZone(url)

    if (!r || !r.out) {
      return escrever(
        '❌ Não consegui bypassar este link.\n\n' +
          '✦ Links de *key Delta* (Linkvertise/Work.ink) mudam muito.\n' +
          '✦ APIs free públicas estão instáveis/fechadas.\n\n' +
          'Opcional: coloque *zoneApiKey* em settings/settings.js\n' +
          'e tente de novo.\n\n' +
          '• ' +
          nome
      )
    }

    try {
      await reagir(from, '✅')
    } catch {}

    const out = r.out
    if (pareceKeyDelta(out)) {
      return escrever(
        '🔑 *KEY DELTA (bypass)*\n\n' +
          '✦ Key: `' +
          out +
          '`\n' +
          '✦ Fonte: ' +
          r.fonte +
          '\n' +
          '✦ Original: ' +
          url +
          '\n\n' +
          '• ' +
          nome
      )
    }

    let extra = ''
    if (r.cadeia && r.cadeia.length > 1) {
      extra =
        '\n✦ Cadeia: ' +
        r.cadeia.length +
        ' hops'
    }

    return escrever(
      '🔗 *LINK BYPASSADO*\n\n' +
        '✦ Original: ' +
        url +
        '\n' +
        '✦ Final: ' +
        out +
        '\n' +
        '✦ Fonte: ' +
        r.fonte +
        extra +
        '\n\n' +
        '• ' +
        nome
    )
  } catch (e) {
    console.log('[bypass]', e && e.message)
    return escrever('❌ Falha no bypass: ' + ((e && e.message) || e) + '\n\n• ' + nome)
  }
}

module.exports = run
module.exports.run = async function (opts) {
  opts = opts || {}
  return run(opts.client || opts.sock, opts.info || opts.m, opts.args || [], opts.contexto || opts)
}
