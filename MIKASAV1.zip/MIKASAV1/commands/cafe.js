const { enviarAcaoGif } = require("../lib/gifAction")
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: "cafe",
        emoji: "☕",
        frase: "deu café pra {alvo}",
        gifQuery: "anime coffee",
        precisaAlvo: true,
        args
    })
}
