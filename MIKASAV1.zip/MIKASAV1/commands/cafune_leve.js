const grupos=require('../lib/grupos')
const config=require('../lib/config')
const {acaoGif}=require('../lib/gifaction')
module.exports=async(client,info,args,ctx)=>{
ctx.args=args;
if(ctx.from.endsWith('@g.us')&&!grupos.brincadeirasAtivas(ctx.from))return ctx.escrever('🚫 Brincadeiras off');
await acaoGif(client,info,ctx,{emoji:'✨',queryGif:'anime',frase:'{eu} fez *cafune leve* com {alvo}'+'\n\n'+config.footer(),precisaAlvo:true,exemplo:config.prefix()+'cafune_leve @user'})
}
