const { enviarAcaoGif } = require("../lib/gifAction")
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: "cair",
        emoji: "💫",
        frase: "caiu em cima de {alvo}",
        gifQuery: "anime fall",
        precisaAlvo: true,
        args
    })
}
