module.exports = async (client, info, args, ctx) => {
  const q = (ctx.texto || args.join(' ') || '').replace(/[^0-9+\-*/().%\s]/g, '')
  if (!q) return ctx.escrever('❌ Ex: calcular 2+2*5')
  try { const r = Function('"use strict";return (' + q + ')')(); await ctx.escrever('🧮 *' + r + '*') } catch { await ctx.escrever('❌ Inválido') }
}
