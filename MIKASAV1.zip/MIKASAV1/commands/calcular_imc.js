const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *calcular imc*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'calcular_imc*')+'\n\n'+config.footer())}
