const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *calcular media*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'calcular_media*')+'\n\n'+config.footer())}
