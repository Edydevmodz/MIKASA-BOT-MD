const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *calcular porcentagem*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'calcular_porcentagem*')+'\n\n'+config.footer())}
