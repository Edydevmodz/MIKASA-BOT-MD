const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *calendario*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'calendario*')+'\n\n'+config.footer())}
