/**
 * FULL CONFIG — /call (System Zero Baileys)
 * Privado only | startCall | wait accept | playCallAudio ready
 */
const config = require('../lib/config')

module.exports = async (client, info, args, contexto) => {
    const { from, escrever, reagir, prefix: px } = contexto
    const prefix = px || config.prefix()

    try { await reagir(from, '📞') } catch {}

    if (from.endsWith('@g.us')) {
        return await escrever('❌ O comando *call* só funciona no *privado*.')
    }

    if (typeof client.startCall !== 'function') {
        return await escrever(
            '⚠️ Esta versão da Baileys não tem *startCall*.\n' +
            'Instale: `npm install @systemzero/baileys`\n' +
            'E também: `npm install opusscript` + ffmpeg no sistema.'
        )
    }

    global.chamadasAtivas = global.chamadasAtivas || {}
    global.callAudioQueue = global.callAudioQueue || {}

    // Encerra call anterior neste chat
    if (global.chamadasAtivas[from]) {
        try {
            if (typeof client.endCall === 'function') {
                await client.endCall(global.chamadasAtivas[from])
            } else if (typeof client.rejectCall === 'function') {
                await client.rejectCall(global.chamadasAtivas[from], from)
            }
        } catch (e) {
            console.error('[CALL] end anterior', e?.message)
        }
        delete global.chamadasAtivas[from]
        delete global.callAudioQueue[from]
    }

    let msgKey = null
    try {
        const sent = await client.sendMessage(from, {
            text: '📞 *Mikasa ligando...*\nAtende aí! 💕\n\n⏱️ Você tem *30s* pra atender.'
        }, { quoted: info })
        msgKey = sent?.key
    } catch {
        await escrever('📞 *Mikasa ligando...* Atende aí!')
    }

    let callId
    try {
        // System Zero: startCall(jid, originChatId?)
        const result = await client.startCall(from, from)
        callId = result?.callId || result?.id || result
        if (!callId) throw new Error('startCall não retornou callId')
    } catch (e) {
        console.error('[CALL] startCall', e)
        return await escrever('❌ Não consegui iniciar a ligação.\n' + (e?.message || e))
    }

    global.chamadasAtivas[from] = callId

    // Aguarda aceite (30s)
    try {
        await new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                try { client.ev.off('call', onCall) } catch {}
                reject(new Error('Tempo esgotado — ninguém atendeu em 30s'))
            }, 30000)

            const onCall = async (calls) => {
                for (const call of calls || []) {
                    if (call.id !== callId) continue
                    if (call.status === 'accept') {
                        clearTimeout(timeout)
                        try { client.ev.off('call', onCall) } catch {}
                        resolve(true)
                    } else if (['reject', 'timeout', 'busy', 'offline', 'terminate'].includes(call.status)) {
                        clearTimeout(timeout)
                        try { client.ev.off('call', onCall) } catch {}
                        reject(new Error('Chamada ' + call.status))
                    }
                }
            }
            client.ev.on('call', onCall)
        })
    } catch (e) {
        delete global.chamadasAtivas[from]
        try {
            if (typeof client.endCall === 'function') await client.endCall(callId)
        } catch {}
        const textoFail = '❌ ' + (e?.message || 'Ligação não atendida')
        if (msgKey) {
            try {
                await client.sendMessage(from, { text: textoFail, edit: msgKey })
            } catch {
                await escrever(textoFail)
            }
        } else {
            await escrever(textoFail)
        }
        return
    }

    const textoOk =
`🎉 *Tô na call!*

🎵 Quer música?
*${prefix}tocar nome da música*

🛑 Desligar:
*${prefix}desligarcall*

💡 Dica: use *mp3* curto pra áudio mais estável.`

    if (msgKey) {
        try {
            await client.sendMessage(from, { text: textoOk, edit: msgKey })
        } catch {
            await escrever(textoOk)
        }
    } else {
        await escrever(textoOk)
    }
}
