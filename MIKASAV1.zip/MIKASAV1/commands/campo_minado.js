const zone = require('../lib/zoneApi')
module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto, prefix } = ctx || {}
  const q = (texto || (args || []).join(' ') || '').trim()
  try { await reagir(from, '⚡') } catch {}
  if (!q) {
    return escrever(
      '⚡ *campo minado.*\n' +
      "cria uma partida de campo minado." + '\n\n' +
      'Uso: *' + (prefix || '/') + 'campo_minado <texto/url>*'
    )
  }
  await escrever('⏳ zone.api.br…')
  try {
    const data = await zone.get("/api/campo-minado", { q, text: q, prompt: q, url: q, query: q, job_id: q })
    let out = typeof data === 'string' ? data : (data?.result || data?.resultado || data?.response || data?.message || data?.texto || data)
    if (typeof out !== 'string') out = JSON.stringify(out, null, 2)
    out = String(out).slice(0, 3500)
    const media = data?.url || data?.result?.url || data?.resultado?.url || data?.download || data?.result?.download
    if (media && /^https?:\/\//i.test(String(media))) {
      try {
        const isImg = /\.(jpg|jpeg|png|webp)(\?|$)/i.test(media)
        if (isImg) await client.sendMessage(from, { image: { url: media }, caption: out.slice(0, 900) }, { quoted: info })
        else await client.sendMessage(from, { video: { url: media }, caption: out.slice(0, 400) }, { quoted: info })
        return
      } catch {}
    }
    await escrever('⚡ *campo minado.*\n\n' + out)
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
