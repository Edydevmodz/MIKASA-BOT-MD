module.exports = require('./campo_minado.js')
