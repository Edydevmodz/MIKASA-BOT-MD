module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto } = ctx || {}
  try { await reagir(from, '✨') } catch {}
  try {
    await escrever('📢 Canal:\nhttps://whatsapp.com/channel/0029VbDsE0sGJP89Q24xAG01')
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
