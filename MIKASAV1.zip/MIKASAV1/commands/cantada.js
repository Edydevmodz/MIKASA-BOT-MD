const L=['Seu nome é Wi-Fi?','Você é Google?','Não sou fotógrafo, mas...'];module.exports=async(c,i,a,ctx)=>ctx.escrever('💘 '+L[Math.floor(Math.random()*L.length)])
