const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *cantada boa*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'cantada_boa*')+'\n\n'+config.footer())}
