const { enviarAcaoGif } = require('../lib/gifAction')
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: 'cantar',
        emoji: '🎤',
        frase: '{user} cantou pra {alvo}',
        gifQuery: 'anime sing gif',
        precisaAlvo: true,
        args
    })
}
