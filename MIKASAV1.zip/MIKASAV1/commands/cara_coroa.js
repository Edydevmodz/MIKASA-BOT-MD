const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *cara coroa*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'cara_coroa*')+'\n\n'+config.footer())}
