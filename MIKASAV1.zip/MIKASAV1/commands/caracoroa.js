module.exports = async (client, info, args, ctx) => {
  await ctx.escrever(Math.random() < 0.5 ? '🪙 *Cara*' : '🪙 *Coroa*')
}
