const { enviarAcaoGif } = require("../lib/gifAction")
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: "carregar_costas",
        emoji: "🎒",
        frase: "carregou {alvo} nas costas",
        gifQuery: "anime piggyback",
        precisaAlvo: true,
        args
    })
}
