const { enviarAcaoGif } = require("../lib/gifAction")
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: "carregou",
        emoji: "🏋️",
        frase: "carregou {alvo}",
        gifQuery: "anime carry",
        precisaAlvo: true,
        args
    })
}
