module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto, prefix, info: inf } = ctx || {}
  const remetenteJid = info?.key?.participant || info?.key?.remoteJid
  try { await reagir(from, '✨') } catch {}
  try {
    const p=(texto||'').trim().split(/\s+/).filter(Boolean);if(p.length<2)return escrever('❌ /casal nome1 nome2 ...');const a=p[Math.floor(Math.random()*p.length)];let b=p[Math.floor(Math.random()*p.length)];while(b===a&&p.length>1)b=p[Math.floor(Math.random()*p.length)];await escrever('💑 Casal do momento: *'+a+'* + *'+b+'*')
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
