module.exports = async (client, info, args, ctx) => {
  const { from, escrever, reagir, texto } = ctx || {}
  try { await reagir(from, '✨') } catch {}
  try {
    const p = (texto || '').trim().split(/\s+/).filter(Boolean)
    if (p.length < 2) return escrever('❌ /casal2 n1 n2 n3')
    const a = p[Math.floor(Math.random()*p.length)]
    let b = p[Math.floor(Math.random()*p.length)]
    while (b === a) b = p[Math.floor(Math.random()*p.length)]
    await escrever('💑 *' + a + '* + *' + b + '*')
  } catch (e) {
    await escrever('❌ ' + (e.message || e))
  }
}
