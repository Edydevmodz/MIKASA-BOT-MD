const config=require('../lib/config')
module.exports=async(client,info,args,ctx)=>{
const q=(ctx.texto||args.join(' ')||'').trim();
await ctx.escrever('✨ *casal famoso*\n'+(q?'Entrada: '+q:'Use: *'+config.prefix()+'casal_famoso*')+'\n\n'+config.footer())}
