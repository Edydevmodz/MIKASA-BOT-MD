const { enviarAcaoGif } = require('../lib/gifAction')
module.exports = async (client, info, args, contexto) => {
    await enviarAcaoGif(client, info, contexto, {
        cmd: 'casamentoacao',
        emoji: '💒',
        frase: 'fez casamento falso com {alvo}',
        gifQuery: 'anime wedding gif',
        precisaAlvo: true,
        args
    })
}
