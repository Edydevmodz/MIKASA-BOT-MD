const fs = require('fs')
const path = require('path')
const config = require('../lib/config')
const grupos = require('../lib/grupos')

const arquivo = path.resolve(__dirname, '..', 'casamentos.json')

function ler() {
    try {
        if (!fs.existsSync(arquivo)) fs.writeFileSync(arquivo, '{}', 'utf8')
        return JSON.parse(fs.readFileSync(arquivo, 'utf8') || '{}')
    } catch {
        return {}
    }
}
function salvar(d) {
    fs.writeFileSync(arquivo, JSON.stringify(d, null, 2), 'utf8')
}
function pegarAlvo(info, args) {
    const ctx = info?.message?.extendedTextMessage?.contextInfo || {}
    if (ctx.mentionedJid?.[0]) return ctx.mentionedJid[0]
    if (args?.[0]) {
        const n = String(args[0]).replace(/\D/g, '')
        if (n) return n + '@s.whatsapp.net'
    }
    return null
}
function tempoJuntos(iso) {
    try {
        const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000)
        const d = Math.floor(s / 86400)
        const h = Math.floor((s % 86400) / 3600)
        const m = Math.floor((s % 3600) / 60)
        return `${d}d ${h}h ${m}m`
    } catch {
        return '—'
    }
}

global.pedidosCasamento = global.pedidosCasamento || {}

module.exports = async (client, info, args, contexto) => {
    const { from, remetenteJid, pushName, escrever, reagir, texto } = contexto
    const prefix = config.prefix()
    const foot = config.footer()

    if (from.endsWith('@g.us') && !grupos.brincadeirasAtivas(from)) {
        return await escrever('🚫 Brincadeiras off.\nAdmin: *' + prefix + 'brincadeiras 1*')
    }

    try { await reagir(from, '💍') } catch {}

    const casamentos = ler()
    const bodyLow = String(texto || args.join(' ') || '').trim().toLowerCase()

    // Aceitar / recusar pedido pendente
    if (bodyLow === 'sim' || bodyLow === 'não' || bodyLow === 'nao') {
        const pedido = Object.values(global.pedidosCasamento).find(
            p => p.alvo === remetenteJid && p.from === from
        )
        if (!pedido) return // deixa outros sistemas tratarem
        if (bodyLow === 'sim') {
            const agora = new Date().toISOString()
            casamentos[pedido.remetente] = {
                parceiro: pedido.alvo,
                inicio: agora,
                nomeA: pedido.nomeA,
                nomeB: pushName || 'Alguém'
            }
            casamentos[pedido.alvo] = {
                parceiro: pedido.remetente,
                inicio: agora,
                nomeA: pushName || 'Alguém',
                nomeB: pedido.nomeA
            }
            salvar(casamentos)
            delete global.pedidosCasamento[pedido.remetente + from]
            return await escrever(
                `💒 *Casamento realizado!*\n\n` +
                `💍 @${pedido.remetente.split('@')[0]} ❤️ @${pedido.alvo.split('@')[0]}\n` +
                `Que sejam felizes! ✨\n${foot}`,
            )
        }
        delete global.pedidosCasamento[pedido.remetente + from]
        return await escrever(`💔 @${pedido.alvo.split('@')[0]} recusou o pedido... onww...`)
    }

    // Já casado?
    if (casamentos[remetenteJid]) {
        const d = casamentos[remetenteJid]
        return await escrever(
            `💍 Você já está casado(a) com @${String(d.parceiro).split('@')[0]}!\n` +
            `⏱️ Juntos há: *${tempoJuntos(d.inicio)}*\n` +
            `Para terminar: *${prefix}divorciar*\n${foot}`
        )
    }

    const alvo = pegarAlvo(info, args)
    if (!alvo) {
        return await escrever(`❌ Marque alguém.\nEx: *${prefix}casar @usuario*`)
    }
    if (alvo === remetenteJid) {
        return await escrever('💍 Casar consigo mesmo? Onww... que carente...')
    }
    if (casamentos[alvo]) {
        return await escrever('❌ Essa pessoa já está casada!')
    }

    global.pedidosCasamento[remetenteJid + from] = {
        remetente: remetenteJid,
        alvo,
        from,
        nomeA: pushName || 'Alguém',
        ts: Date.now()
    }

    await client.sendMessage(
        from,
        {
            text:
                `💍 *Pedido de casamento!*\n\n` +
                `@${remetenteJid.split('@')[0]} pediu @${alvo.split('@')[0]} em casamento!\n\n` +
                `Responda:\n✅ *sim* — aceitar\n❌ *não* — recusar\n\n${foot}`,
            mentions: [remetenteJid, alvo]
        },
        { quoted: info }
    )
}
