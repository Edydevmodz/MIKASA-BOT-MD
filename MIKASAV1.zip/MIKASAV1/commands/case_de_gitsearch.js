module.exports = require('./casedegitsearch.js')
