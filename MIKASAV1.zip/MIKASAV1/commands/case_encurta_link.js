module.exports = require('./caseencurtalink.js')
