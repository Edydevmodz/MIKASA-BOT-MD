module.exports = require('./caseselospart1.js')
