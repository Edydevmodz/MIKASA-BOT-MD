module.exports = require('./case_black_pink.js')
