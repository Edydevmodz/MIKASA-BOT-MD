module.exports = require('./case_dado.js')
