module.exports = require('./case_deadpool.js')
