module.exports = require('./case_de_busca_por_placas.js')
