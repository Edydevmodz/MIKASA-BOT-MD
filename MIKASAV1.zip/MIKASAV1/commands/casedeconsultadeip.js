module.exports = require('./case_de_consulta_de_ip.js')
