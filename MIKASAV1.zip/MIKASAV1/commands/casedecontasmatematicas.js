module.exports = require('./case_de_contas_matematicas.js')
