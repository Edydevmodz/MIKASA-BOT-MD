module.exports = require('./case_de_copiar_a_mensagem.js')
