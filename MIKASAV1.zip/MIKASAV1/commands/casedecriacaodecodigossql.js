module.exports = require('./case_de_criacao_de_codigos_sql.js')
