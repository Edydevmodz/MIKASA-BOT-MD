module.exports = require('./case_de_forca.js')
