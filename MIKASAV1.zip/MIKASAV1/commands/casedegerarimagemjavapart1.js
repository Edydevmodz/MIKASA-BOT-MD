module.exports = require('./case_de_gerar_imagem_java_part_1.js')
