module.exports = require('./case_de_gerar_qr_code.js')
