module.exports = require('./case_de_nano_banana_editor.js')
