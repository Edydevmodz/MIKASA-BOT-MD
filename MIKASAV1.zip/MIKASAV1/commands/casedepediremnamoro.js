module.exports = require('./case_de_pedir_em_namoro.js')
