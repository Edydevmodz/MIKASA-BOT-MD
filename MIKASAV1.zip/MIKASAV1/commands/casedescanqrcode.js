module.exports = require('./case_de_scan_qr_code.js')
