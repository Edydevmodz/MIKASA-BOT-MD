module.exports = require('./case_de_teste_de_api.js')
